let handler = async (m, { conn }) => {
    conn.reply(m.chat, 'Selamat anda mendapatkan +500 XP', m)
    global.DATABASE._data.users[m.sender].exp += 700009
    global.DATABASE._data.users[m.semder].money += 999999
    global.DATABASE._data.users[m.sender].lastclaim = new Date * 1
  }
}
handler.help = ['farming', 'cheat']]
handler.tags = ['owner']
handler.command = /^(farming|cheat)$/i
handler.owner = false
handler.groups = false

handler.fail = null
handler.exp = 0

module.exports = handler
