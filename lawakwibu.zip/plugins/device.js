let handler = async m => m.reply(`
╭─「 Device 」
│ • RAM: 6GB
│ • Internal: 128GB
│ • VPS RAM: 4GB
│ • Device: Xiaomi Redmi Note 8 PRO
│ • VPSType: Ubuntu 20.04 LTS
│ • DPI: 490
│ • Android Version: 10
│ • CPU MODEL: Snapdragon 665 2,02 GHz
│ • Clock Speed CPU: 300 MHz - 2,02 GHZ
│ • GPU: Andreno
│ • LocalhostUsage: Web Server - LinuxOS - Servers
│ • ROOT: No
│ • Browser: Chrome
│ • Server: Baileys
│ • Games: Mobile Legends, Minecraft, Call Of Duty, PUBG
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['device']
handler.tags = ['info']
handler.command = /^device$/i

module.exports = handler
