let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.asu)}”`, m)
}
handler.help = ['gombal']
handler.tags = ['quotes']
handler.command = /^(gombal)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.asu = [
" *Gombal*\n\n*Walau Aku Tidak Bisa Menambang\nTetapi Aku Tetap Bisa Mencuri Hati Mu",
" *asu*",
]
