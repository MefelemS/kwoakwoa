let handler = async m => m.reply(`
╭─「 Donasi 」
│ • Gopay [628895133276]
│ • Saweria [saweria.co/Meflems]
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
